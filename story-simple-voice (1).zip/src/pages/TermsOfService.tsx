import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const TermsOfService = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Link to="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-center">
              Terms of Service
            </CardTitle>
            <p className="text-center text-muted-foreground">
              Last updated: {new Date().toLocaleDateString()}
            </p>
          </CardHeader>
          <CardContent className="prose max-w-none">
            <h2>1. Acceptance of Terms</h2>
            <p>By accessing and using EzClickVideoMaker, you accept and agree to be bound by the terms and provision of this agreement.</p>
            
            <h2>2. Use License</h2>
            <p>Permission is granted to temporarily download one copy of EzClickVideoMaker materials for personal, non-commercial transitory viewing only.</p>
            
            <h2>3. Disclaimer</h2>
            <p>The materials on EzClickVideoMaker are provided on an 'as is' basis. Something Useful, Inc. makes no warranties, expressed or implied.</p>
            
            <h2>4. Limitations</h2>
            <p>In no event shall Something Useful, Inc. or its suppliers be liable for any damages arising out of the use or inability to use the materials.</p>
            
            <h2>5. Governing Law</h2>
            <p>These terms and conditions are governed by and construed in accordance with the laws of the United States.</p>
            
            <h2>6. Contact Information</h2>
            <p>For questions regarding these Terms of Service, contact Something Useful, Inc. at Ezclickvideomaker@gmail.com</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default TermsOfService;