import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";

const RefundPolicy = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <Link to="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
        
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-center">
              Refund Policy
            </CardTitle>
            <p className="text-center text-muted-foreground">
              Last updated: {new Date().toLocaleDateString()}
            </p>
          </CardHeader>
          <CardContent className="prose max-w-none">
            <h2>1. 30-Day Money Back Guarantee</h2>
            <p>We offer a full refund within 30 days of your initial purchase if you're not satisfied with EzClickVideoMaker.</p>
            
            <h2>2. Refund Process</h2>
            <p>To request a refund, contact our support team at Ezclickvideomaker@gmail.com with your order number and reason for the refund request.</p>
            
            <h2>3. Processing Time</h2>
            <p>Refunds are typically processed within 5-7 business days after approval. The refund will be credited to your original payment method.</p>
            
            <h2>4. Subscription Cancellations</h2>
            <p>You can cancel your subscription at any time. Cancellations take effect at the end of your current billing period.</p>
            
            <h2>5. Non-Refundable Items</h2>
            <p>Custom video creation services and premium add-ons may not be eligible for refunds once completed.</p>
            
            <h2>6. Contact Us</h2>
            <p>For refund inquiries, contact Something Useful, Inc. at Ezclickvideomaker@gmail.com or call our support line.</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default RefundPolicy;