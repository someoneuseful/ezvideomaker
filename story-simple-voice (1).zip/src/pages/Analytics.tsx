import React from 'react';
import { AnalyticsDashboard } from '@/components/AnalyticsDashboard';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

const Analytics: React.FC = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-8">
        <AnalyticsDashboard />
      </main>
      <Footer />
    </div>
  );
};

export default Analytics;