import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import ContentRating from "@/components/ContentRating";
import DataSafety from "@/components/DataSafety";
import AppPermissions from "@/components/AppPermissions";

const GooglePlayCompliance = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-blue-50 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-6">
          <Link to="/">
            <Button variant="ghost" className="mb-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Home
            </Button>
          </Link>
        </div>
        
        <Card className="mb-8">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold">
              Google Play Store Compliance
            </CardTitle>
            <p className="text-muted-foreground">
              EzClickVideoMaker meets all Google Play Store requirements
            </p>
          </CardHeader>
        </Card>
        
        <div className="grid gap-8 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-3">
          <ContentRating />
          <div className="lg:col-span-2">
            <DataSafety />
          </div>
          <div className="lg:col-span-3">
            <AppPermissions />
          </div>
        </div>
        
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Additional Compliance Information</CardTitle>
          </CardHeader>
          <CardContent className="prose max-w-none">
            <div className="grid gap-6 md:grid-cols-2">
              <div>
                <h3 className="font-semibold mb-2">Target SDK Version</h3>
                <p className="text-sm text-muted-foreground">API Level 34 (Android 14)</p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">App Category</h3>
                <p className="text-sm text-muted-foreground">Photography & Video</p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Content Guidelines</h3>
                <p className="text-sm text-muted-foreground">Follows Google Play content policy</p>
              </div>
              <div>
                <h3 className="font-semibold mb-2">Security</h3>
                <p className="text-sm text-muted-foreground">No malicious behavior or security vulnerabilities</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default GooglePlayCompliance;