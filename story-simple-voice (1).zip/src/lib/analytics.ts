// Analytics and crash logging utilities

interface AnalyticsEvent {
  name: string;
  properties?: Record<string, any>;
}

interface CrashReport {
  error: Error;
  context?: Record<string, any>;
  userId?: string;
}

class Analytics {
  private static instance: Analytics;
  private userId: string | null = null;
  private isEnabled: boolean = true;

  static getInstance(): Analytics {
    if (!Analytics.instance) {
      Analytics.instance = new Analytics();
    }
    return Analytics.instance;
  }

  setUserId(userId: string) {
    this.userId = userId;
  }

  setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
  }

  track(event: AnalyticsEvent) {
    if (!this.isEnabled) return;
    
    console.log('Analytics Event:', {
      ...event,
      userId: this.userId,
      timestamp: new Date().toISOString()
    });
    
    // Store in localStorage for persistence
    this.storeEvent(event);
  }

  private storeEvent(event: AnalyticsEvent) {
    try {
      const events = JSON.parse(localStorage.getItem('analytics_events') || '[]');
      events.push({
        ...event,
        userId: this.userId,
        timestamp: new Date().toISOString()
      });
      
      // Keep only last 100 events
      if (events.length > 100) {
        events.splice(0, events.length - 100);
      }
      
      localStorage.setItem('analytics_events', JSON.stringify(events));
    } catch (error) {
      console.error('Failed to store analytics event:', error);
    }
  }

  getStoredEvents() {
    try {
      return JSON.parse(localStorage.getItem('analytics_events') || '[]');
    } catch {
      return [];
    }
  }
}

class CrashLogger {
  private static instance: CrashLogger;
  private isEnabled: boolean = true;

  static getInstance(): CrashLogger {
    if (!CrashLogger.instance) {
      CrashLogger.instance = new CrashLogger();
    }
    return CrashLogger.instance;
  }

  setEnabled(enabled: boolean) {
    this.isEnabled = enabled;
  }

  logCrash(report: CrashReport) {
    if (!this.isEnabled) return;
    
    const crashData = {
      message: report.error.message,
      stack: report.error.stack,
      context: report.context,
      userId: report.userId,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      url: window.location.href
    };
    
    console.error('Crash Report:', crashData);
    
    // Store crash report
    this.storeCrash(crashData);
  }

  private storeCrash(crashData: any) {
    try {
      const crashes = JSON.parse(localStorage.getItem('crash_reports') || '[]');
      crashes.push(crashData);
      
      // Keep only last 50 crashes
      if (crashes.length > 50) {
        crashes.splice(0, crashes.length - 50);
      }
      
      localStorage.setItem('crash_reports', JSON.stringify(crashes));
    } catch (error) {
      console.error('Failed to store crash report:', error);
    }
  }

  getStoredCrashes() {
    try {
      return JSON.parse(localStorage.getItem('crash_reports') || '[]');
    } catch {
      return [];
    }
  }
}

export const analytics = Analytics.getInstance();
export const crashLogger = CrashLogger.getInstance();

// Convenience functions
export const trackEvent = (name: string, properties?: Record<string, any>) => {
  analytics.track({ name, properties });
};

export const logError = (error: Error, context?: Record<string, any>) => {
  crashLogger.logCrash({ error, context });
};