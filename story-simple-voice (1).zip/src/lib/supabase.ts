import { createClient } from '@supabase/supabase-js';

// Initialize Supabase client
const supabaseUrl = 'https://duydslysiatopsslsijc.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImR1eWRzbHlzaWF0b3Bzc2xzaWpjIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTAwNzc0MDEsImV4cCI6MjA2NTY1MzQwMX0.8KXBHXVknErZyqSnn3tBOg06TCroK8e_qVVd0oZn2UU';

export const supabase = createClient(supabaseUrl, supabaseKey);

// Database types
export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  subscription_tier?: string;
  subscription_status?: string;
  created_at?: string;
}

export interface Video {
  id: string;
  user_id: string;
  title: string;
  story: string;
  voice_id: string;
  status: 'processing' | 'completed' | 'failed';
  video_url?: string;
  created_at: string;
}