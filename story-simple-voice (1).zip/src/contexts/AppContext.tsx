import React, { createContext, useContext, useState } from 'react';

interface UserData {
  id?: string;
  username: string;
  name: string;
  email: string;
  subscription_tier?: string;
  subscription_status?: string;
}

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  videosRemaining: number;
  isPro: boolean;
  currentPlan: string;
  userData: UserData | null;
  setUserData: (data: UserData) => void;
  isUserRegistered: boolean;
  upgradeSubscription: (planId: string, userData?: any) => void;
}

const defaultAppContext: AppContextType = {
  sidebarOpen: false,
  toggleSidebar: () => {},
  videosRemaining: 2,
  isPro: false,
  currentPlan: 'free',
  userData: null,
  setUserData: () => {},
  isUserRegistered: false,
  upgradeSubscription: () => {},
};

const AppContext = createContext<AppContextType>(defaultAppContext);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [videosRemaining, setVideosRemaining] = useState(2);
  const [isPro, setIsPro] = useState(false);
  const [currentPlan, setCurrentPlan] = useState('free');
  const [userData, setUserDataState] = useState<UserData | null>(null);

  const toggleSidebar = () => {
    setSidebarOpen(prev => !prev);
  };

  const setUserData = (data: UserData) => {
    setUserDataState(data);
  };

  const upgradeSubscription = (planId: string, newUserData?: any) => {
    setCurrentPlan(planId);
    setIsPro(planId === 'pro' || planId === 'enterprise');
    if (planId === 'pro') {
      setVideosRemaining(999);
    } else if (planId === 'enterprise') {
      setVideosRemaining(999);
    }
    
    if (newUserData) {
      setUserDataState({
        id: newUserData.id,
        username: newUserData.email,
        name: newUserData.name,
        email: newUserData.email,
        subscription_tier: newUserData.subscription_tier,
        subscription_status: newUserData.subscription_status
      });
    }
  };

  const isUserRegistered = userData !== null;

  return (
    <AppContext.Provider
      value={{
        sidebarOpen,
        toggleSidebar,
        videosRemaining,
        isPro,
        currentPlan,
        userData,
        setUserData,
        isUserRegistered,
        upgradeSubscription,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};