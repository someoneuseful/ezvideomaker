import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Play, Download, Upload, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAnalyticsContext } from '@/components/AnalyticsProvider';
import { logError } from '@/lib/analytics';
import VoiceSelector from './VoiceSelector';

const VideoCreator: React.FC = () => {
  const [story, setStory] = useState('');
  const [selectedVoice, setSelectedVoice] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [videoUrl, setVideoUrl] = useState('');
  const [selectedImages, setSelectedImages] = useState<File[]>([]);
  const { toast } = useToast();
  const { trackEvent } = useAnalyticsContext();

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (selectedImages.length + files.length > 10) {
      toast({ title: 'Too many images', description: 'You can upload up to 10 images.' });
      trackEvent('image_upload_limit_exceeded', { attempted: files.length, current: selectedImages.length });
      return;
    }
    setSelectedImages(prev => [...prev, ...files]);
    trackEvent('images_uploaded', { count: files.length, total: selectedImages.length + files.length });
  };

  const removeImage = (index: number) => {
    setSelectedImages(prev => prev.filter((_, i) => i !== index));
    trackEvent('image_removed', { index, remaining: selectedImages.length - 1 });
  };

  const generateVideo = async () => {
    trackEvent('video_generation_started', { 
      storyLength: story.length, 
      voiceSelected: selectedVoice,
      imageCount: selectedImages.length 
    });
    
    if (!story || !selectedVoice) {
      toast({ title: 'Missing information', description: 'Please add your story and select a voice.' });
      trackEvent('video_generation_failed', { reason: 'missing_info' });
      return;
    }
    
    if (selectedImages.length === 0) {
      toast({ title: 'No images', description: 'Please upload at least one image.' });
      trackEvent('video_generation_failed', { reason: 'no_images' });
      return;
    }
    
    setIsGenerating(true);
    
    try {
      const mockUserId = 'user-123';
      
      const response = await fetch(
        'https://duydslysiatopsslsijc.supabase.co/functions/v1/c715e0c3-9f57-4c78-b35e-fb4ad5267450',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            userId: mockUserId,
            prompt: `Create a video with voice ${selectedVoice} telling this story: ${story}`,
            imageCount: selectedImages.length,
            voiceId: selectedVoice
          })
        }
      );
      
      const result = await response.json();
      
      if (result.success) {
        setVideoUrl(result.videoUrl);
        toast({ title: 'Video created!', description: 'Your story video is ready!' });
        trackEvent('video_generation_success', { 
          videoUrl: result.videoUrl,
          processingTime: Date.now() 
        });
      } else {
        throw new Error(result.error || 'Video generation failed');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An error occurred';
      logError(error instanceof Error ? error : new Error(errorMessage), {
        context: 'video_generation',
        story: story.substring(0, 100),
        voice: selectedVoice,
        imageCount: selectedImages.length
      });
      
      toast({
        title: 'Generation Failed',
        description: errorMessage,
        variant: 'destructive',
      });
      
      trackEvent('video_generation_error', { error: errorMessage });
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDownload = () => {
    trackEvent('video_downloaded', { videoUrl });
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Upload Your Pictures (Up to 10)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={handleImageUpload}
                className="hidden"
                id="image-upload"
              />
              <label htmlFor="image-upload" className="cursor-pointer">
                <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-gray-600">Click to upload images</p>
                <p className="text-sm text-gray-400">{selectedImages.length}/10 images selected</p>
              </label>
            </div>
            
            {selectedImages.length > 0 && (
              <div className="grid grid-cols-5 gap-2">
                {selectedImages.map((file, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={URL.createObjectURL(file)}
                      alt={`Upload ${index + 1}`}
                      className="w-full h-16 object-cover rounded border"
                    />
                    <button
                      onClick={() => removeImage(index)}
                      className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Tell Your Story</CardTitle>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Share your story, lesson, or message here..."
            value={story}
            onChange={(e) => setStory(e.target.value)}
            rows={4}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Choose Your Voice</CardTitle>
        </CardHeader>
        <CardContent>
          <VoiceSelector
            selectedVoice={selectedVoice}
            onVoiceChange={setSelectedVoice}
          />
        </CardContent>
      </Card>

      <Button 
        onClick={generateVideo} 
        disabled={isGenerating || selectedImages.length === 0}
        className="w-full"
        size="lg"
      >
        {isGenerating ? 'Creating Video...' : 'Create Video'}
      </Button>

      {videoUrl && (
        <Card className="border-green-200 bg-green-50">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="w-full h-48 bg-gray-200 rounded-lg flex items-center justify-center">
                <Play className="h-12 w-12 text-gray-500" />
                <span className="ml-2 text-gray-600">Video Ready</span>
              </div>
              <Button variant="outline" size="sm" onClick={handleDownload}>
                <Download className="h-4 w-4 mr-2" />
                Download Video
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default VideoCreator;