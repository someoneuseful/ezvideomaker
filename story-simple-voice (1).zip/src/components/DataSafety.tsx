import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Shield, Eye, Lock, Database } from "lucide-react";

const DataSafety = () => {
  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-2">
          <Shield className="h-8 w-8 text-green-600" />
        </div>
        <CardTitle className="text-xl">Data Safety</CardTitle>
        <p className="text-sm text-muted-foreground">
          Your privacy and data security are our top priorities
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid gap-4">
          <div className="flex items-start gap-3">
            <Eye className="h-5 w-5 text-blue-600 mt-1" />
            <div>
              <h3 className="font-semibold">Data Collection</h3>
              <p className="text-sm text-muted-foreground">
                We collect only essential data: email for account creation, uploaded images for video processing
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <Lock className="h-5 w-5 text-green-600 mt-1" />
            <div>
              <h3 className="font-semibold">Data Encryption</h3>
              <p className="text-sm text-muted-foreground">
                All data is encrypted in transit and at rest using industry-standard encryption
              </p>
            </div>
          </div>
          
          <div className="flex items-start gap-3">
            <Database className="h-5 w-5 text-purple-600 mt-1" />
            <div>
              <h3 className="font-semibold">Data Sharing</h3>
              <p className="text-sm text-muted-foreground">
                We do not sell or share your personal data with third parties for advertising
              </p>
            </div>
          </div>
        </div>
        
        <div className="border-t pt-4">
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline">No ads</Badge>
            <Badge variant="outline">GDPR compliant</Badge>
            <Badge variant="outline">CCPA compliant</Badge>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default DataSafety;