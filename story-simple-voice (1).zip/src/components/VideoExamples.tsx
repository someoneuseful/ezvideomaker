import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Play, Eye } from 'lucide-react';

const VideoExamples: React.FC = () => {
  const examples = [
    {
      title: 'Educational Story',
      style: '2D Animation',
      description: 'Math lesson with colorful 2D characters',
      duration: '2:30',
      views: '1.2K'
    },
    {
      title: 'Product Demo',
      style: '3D Animation', 
      description: '3D product showcase with realistic lighting',
      duration: '1:45',
      views: '3.5K'
    },
    {
      title: 'Kids Adventure',
      style: 'Cartoon',
      description: 'Colorful cartoon adventure story',
      duration: '3:15', 
      views: '5.8K'
    },
    {
      title: 'Business Presentation',
      style: 'Whiteboard',
      description: 'Professional whiteboard animation',
      duration: '4:20',
      views: '2.1K'
    }
  ];

  return (
    <div className="py-12 px-6 bg-white/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-10">
          <h3 className="text-3xl font-bold text-gray-800 mb-4">
            Video Examples
          </h3>
          <p className="text-gray-600 max-w-2xl mx-auto">
            See what's possible with our video creation platform.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {examples.map((example, index) => (
            <Card key={index} className="group cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 bg-white border-0 shadow-md">
              <div className="relative overflow-hidden rounded-t-lg bg-gradient-to-br from-purple-100 to-pink-100 h-32 flex items-center justify-center">
                <div className="absolute inset-0 bg-black/10 group-hover:bg-black/5 transition-colors" />
                <Button size="sm" className="bg-white/90 text-gray-700 hover:bg-white">
                  <Play className="w-4 h-4 mr-1" />
                  Play
                </Button>
              </div>
              <CardContent className="p-4">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="outline" className="text-xs">
                    {example.style}
                  </Badge>
                  <div className="flex items-center text-xs text-gray-500">
                    <Eye className="w-3 h-3 mr-1" />
                    {example.views}
                  </div>
                </div>
                <h4 className="font-semibold text-gray-800 mb-1">
                  {example.title}
                </h4>
                <p className="text-sm text-gray-600 mb-2">
                  {example.description}
                </p>
                <div className="text-xs text-gray-500">
                  Duration: {example.duration}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
};

export default VideoExamples;