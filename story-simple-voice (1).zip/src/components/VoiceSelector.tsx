import React, { useState } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { Search } from 'lucide-react';

interface Voice {
  id: string;
  name: string;
  gender: string;
  accent: string;
  style: string;
  language: string;
}

interface VoiceSelectorProps {
  selectedVoice: string;
  onVoiceChange: (voiceId: string) => void;
}

const VoiceSelector: React.FC<VoiceSelectorProps> = ({ selectedVoice, onVoiceChange }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterGender, setFilterGender] = useState('all');
  const [filterLanguage, setFilterLanguage] = useState('all');

  const voices: Voice[] = [
    { id: 'en-us-sarah-friendly', name: 'Sarah', gender: 'Female', accent: 'American', style: 'Friendly', language: 'English' },
    { id: 'en-us-mike-professional', name: 'Mike', gender: 'Male', accent: 'American', style: 'Professional', language: 'English' },
    { id: 'en-us-jessica-cheerful', name: 'Jessica', gender: 'Female', accent: 'American', style: 'Cheerful', language: 'English' },
    { id: 'en-us-david-deep', name: 'David', gender: 'Male', accent: 'American', style: 'Deep', language: 'English' },
    { id: 'en-us-amy-energetic', name: 'Amy', gender: 'Female', accent: 'American', style: 'Energetic', language: 'English' },
    { id: 'en-us-brian-calm', name: 'Brian', gender: 'Male', accent: 'American', style: 'Calm', language: 'English' },
    { id: 'en-us-emma-warm', name: 'Emma', gender: 'Female', accent: 'American', style: 'Warm', language: 'English' },
    { id: 'en-us-ryan-confident', name: 'Ryan', gender: 'Male', accent: 'American', style: 'Confident', language: 'English' },
    { id: 'en-us-olivia-gentle', name: 'Olivia', gender: 'Female', accent: 'American', style: 'Gentle', language: 'English' },
    { id: 'en-us-noah-authoritative', name: 'Noah', gender: 'Male', accent: 'American', style: 'Authoritative', language: 'English' },
    { id: 'en-uk-emma-elegant', name: 'Emma', gender: 'Female', accent: 'British', style: 'Elegant', language: 'English' },
    { id: 'en-uk-james-sophisticated', name: 'James', gender: 'Male', accent: 'British', style: 'Sophisticated', language: 'English' },
    { id: 'en-uk-charlotte-posh', name: 'Charlotte', gender: 'Female', accent: 'British', style: 'Posh', language: 'English' },
    { id: 'en-uk-william-distinguished', name: 'William', gender: 'Male', accent: 'British', style: 'Distinguished', language: 'English' },
    { id: 'en-au-jack-casual', name: 'Jack', gender: 'Male', accent: 'Australian', style: 'Casual', language: 'English' },
    { id: 'en-au-chloe-upbeat', name: 'Chloe', gender: 'Female', accent: 'Australian', style: 'Upbeat', language: 'English' },
    { id: 'es-es-maria-gentle', name: 'María', gender: 'Female', accent: 'Spanish', style: 'Gentle', language: 'Spanish' },
    { id: 'es-mx-carlos-energetic', name: 'Carlos', gender: 'Male', accent: 'Mexican', style: 'Energetic', language: 'Spanish' },
    { id: 'fr-fr-claire-romantic', name: 'Claire', gender: 'Female', accent: 'French', style: 'Romantic', language: 'French' },
    { id: 'fr-ca-pierre-friendly', name: 'Pierre', gender: 'Male', accent: 'Canadian French', style: 'Friendly', language: 'French' },
    { id: 'de-de-anna-clear', name: 'Anna', gender: 'Female', accent: 'German', style: 'Clear', language: 'German' },
    { id: 'de-de-hans-authoritative', name: 'Hans', gender: 'Male', accent: 'German', style: 'Authoritative', language: 'German' },
    { id: 'it-it-sofia-melodic', name: 'Sofia', gender: 'Female', accent: 'Italian', style: 'Melodic', language: 'Italian' },
    { id: 'it-it-marco-passionate', name: 'Marco', gender: 'Male', accent: 'Italian', style: 'Passionate', language: 'Italian' },
    { id: 'pt-br-ana-warm', name: 'Ana', gender: 'Female', accent: 'Brazilian', style: 'Warm', language: 'Portuguese' },
    { id: 'ja-jp-yuki-soft', name: 'Yuki', gender: 'Female', accent: 'Japanese', style: 'Soft', language: 'Japanese' },
    { id: 'ko-kr-min-jun-clear', name: 'Min-jun', gender: 'Male', accent: 'Korean', style: 'Clear', language: 'Korean' },
    { id: 'zh-cn-li-wei-gentle', name: 'Li Wei', gender: 'Female', accent: 'Mandarin', style: 'Gentle', language: 'Chinese' }
  ];

  const filteredVoices = voices.filter(voice => {
    const matchesSearch = voice.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         voice.accent.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         voice.style.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGender = filterGender === 'all' || voice.gender.toLowerCase() === filterGender;
    const matchesLanguage = filterLanguage === 'all' || voice.language === filterLanguage;
    return matchesSearch && matchesGender && matchesLanguage;
  });

  const selectedVoiceData = voices.find(v => v.id === selectedVoice);

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search voices..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={filterGender} onValueChange={setFilterGender}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Gender" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="male">Male</SelectItem>
            <SelectItem value="female">Female</SelectItem>
          </SelectContent>
        </Select>
        <Select value={filterLanguage} onValueChange={setFilterLanguage}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Language" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="English">English</SelectItem>
            <SelectItem value="Spanish">Spanish</SelectItem>
            <SelectItem value="French">French</SelectItem>
            <SelectItem value="German">German</SelectItem>
            <SelectItem value="Italian">Italian</SelectItem>
            <SelectItem value="Portuguese">Portuguese</SelectItem>
            <SelectItem value="Japanese">Japanese</SelectItem>
            <SelectItem value="Korean">Korean</SelectItem>
            <SelectItem value="Chinese">Chinese</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {selectedVoiceData && (
        <div className="p-3 bg-blue-50 rounded-lg border">
          <div className="flex items-center gap-2 mb-2">
            <span className="font-medium">{selectedVoiceData.name}</span>
            <Badge variant="secondary">{selectedVoiceData.accent}</Badge>
            <Badge variant="outline">{selectedVoiceData.style}</Badge>
          </div>
          <p className="text-sm text-gray-600">
            {selectedVoiceData.gender} • {selectedVoiceData.language}
          </p>
        </div>
      )}

      <ScrollArea className="h-64 border rounded-lg">
        <div className="p-2 space-y-1">
          {filteredVoices.map((voice) => (
            <div
              key={voice.id}
              className={`p-3 rounded cursor-pointer transition-colors ${
                selectedVoice === voice.id
                  ? 'bg-blue-100 border-blue-300 border'
                  : 'hover:bg-gray-50'
              }`}
              onClick={() => onVoiceChange(voice.id)}
            >
              <div className="flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{voice.name}</span>
                    <Badge variant="secondary" className="text-xs">{voice.accent}</Badge>
                  </div>
                  <div className="text-sm text-gray-600 mt-1">
                    {voice.gender} • {voice.style}
                  </div>
                </div>
                <Badge variant="outline" className="text-xs">{voice.language}</Badge>
              </div>
            </div>
          ))}
        </div>
      </ScrollArea>

      <p className="text-sm text-gray-500 text-center">
        {filteredVoices.length} voices available
      </p>
    </div>
  );
};

export default VoiceSelector;