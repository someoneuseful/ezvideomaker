import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { useAppContext } from '@/contexts/AppContext';
import { X, Video, Heart, Users, BookOpen, Star, Gift } from 'lucide-react';
import { useIsMobile } from '@/hooks/use-mobile';
import { SubscriptionModal } from './SubscriptionModal';

const Sidebar: React.FC = () => {
  const { sidebarOpen, toggleSidebar, videosRemaining, isPro, currentPlan, upgradeSubscription } = useAppContext();
  const isMobile = useIsMobile();
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  const handleUpgradeClick = () => {
    setShowSubscriptionModal(true);
  };

  const handleSubscriptionSuccess = (planId: string) => {
    upgradeSubscription(planId);
    setShowSubscriptionModal(false);
  };

  const getPlanInfo = () => {
    switch (currentPlan) {
      case 'pro': return { name: 'Pro Plan', price: '$19/mo' };
      case 'enterprise': return { name: 'Enterprise Plan', price: '$49/mo' };
      default: return { name: 'Free Plan', price: 'Free' };
    }
  };

  if (!sidebarOpen && isMobile) return null;

  return (
    <>
      {isMobile && sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40" 
          onClick={toggleSidebar}
        />
      )}
      <aside className={`
        ${isMobile ? 'fixed left-0 top-0 h-full z-50' : 'sticky top-0 h-screen'}
        w-80 bg-gradient-to-b from-purple-50 to-pink-50 border-r border-purple-200 overflow-y-auto
        ${isMobile && !sidebarOpen ? '-translate-x-full' : 'translate-x-0'}
        transition-transform duration-300
      `}>
        <div className="p-4 space-y-4">
          {isMobile && (
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold text-purple-800">Menu</h2>
              <Button variant="ghost" size="sm" onClick={toggleSidebar}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
          
          <Card className={`${isPro ? 'bg-gradient-to-r from-green-500 to-blue-500' : 'bg-gradient-to-r from-purple-500 to-pink-500'} text-white border-0`}>
            <CardContent className="p-4">
              <div className="flex items-center gap-3 mb-3">
                <Gift className="h-6 w-6" />
                <div>
                  <h3 className="font-semibold">{getPlanInfo().name}</h3>
                  <p className="text-xs text-white/80">
                    {videosRemaining === 999 ? 'Unlimited videos' : `${videosRemaining} videos remaining`}
                  </p>
                </div>
              </div>
              {!isPro && (
                <Button 
                  size="sm" 
                  className="w-full bg-white text-purple-600 hover:bg-white/90"
                  onClick={handleUpgradeClick}
                >
                  Upgrade to Pro - $19/mo
                </Button>
              )}
              {isPro && (
                <div className="text-center">
                  <p className="text-sm font-medium">✨ Premium Member ✨</p>
                  <p className="text-xs text-white/80">Thank you for your support!</p>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-2">
            <Button variant="ghost" className="w-full justify-start text-purple-700 hover:bg-purple-100">
              <Video className="h-4 w-4 mr-3" />
              My Videos
            </Button>
            <Button variant="ghost" className="w-full justify-start text-purple-700 hover:bg-purple-100">
              <BookOpen className="h-4 w-4 mr-3" />
              Video Templates
            </Button>
            <Button variant="ghost" className="w-full justify-start text-purple-700 hover:bg-purple-100">
              <Users className="h-4 w-4 mr-3" />
              Community
            </Button>
          </div>

          <Card className="bg-pink-50 border-pink-200">
            <CardContent className="p-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <img 
                  src="https://d64gsuwffb70l.cloudfront.net/68500b41da0586b2a971dad7_1750089688409_28cc4622.jpg" 
                  alt="SUI Logo" 
                  className="h-6 w-6 object-contain"
                />
                <Heart className="h-6 w-6 text-pink-500" />
              </div>
              <h3 className="font-semibold text-pink-800 mb-1">EzClickVideoMaker</h3>
              <p className="text-xs text-pink-600">
                © Something Useful, Inc. - Making video creation effortless
              </p>
            </CardContent>
          </Card>
        </div>
      </aside>

      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        onSubscriptionSuccess={handleSubscriptionSuccess}
      />
    </>
  );
};

export default Sidebar;