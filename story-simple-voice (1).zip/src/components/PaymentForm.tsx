import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { CreditCard, Lock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAnalyticsContext } from '@/components/AnalyticsProvider';
import { logError } from '@/lib/analytics';

interface PaymentFormProps {
  planName: string;
  planPrice: string;
  onPaymentSubmit: (paymentData: any) => void;
  onCancel: () => void;
}

export const PaymentForm: React.FC<PaymentFormProps> = ({ 
  planName, 
  planPrice, 
  onPaymentSubmit, 
  onCancel 
}) => {
  const [formData, setFormData] = useState({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardholderName: '',
    email: '',
    name: ''
  });
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { trackEvent } = useAnalyticsContext();

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    trackEvent('payment_attempt', { 
      planName, 
      planPrice,
      hasEmail: !!formData.email,
      hasCardNumber: !!formData.cardNumber 
    });
    
    try {
      const response = await fetch(
        'https://duydslysiatopsslsijc.supabase.co/functions/v1/45527195-e02a-4872-9202-7d21b2119553',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            email: formData.email,
            name: formData.name || formData.cardholderName,
            planId: planName.toLowerCase(),
            paymentMethod: {
              cardNumber: formData.cardNumber,
              expiryDate: formData.expiryDate,
              cvv: formData.cvv,
              cardholderName: formData.cardholderName
            }
          })
        }
      );
      
      const result = await response.json();
      
      if (result.success) {
        toast({
          title: "Payment Successful!",
          description: `Welcome to ${planName}! Your subscription is now active.`,
        });
        
        trackEvent('payment_success', { 
          planName, 
          planPrice,
          userId: result.userId 
        });
        
        onPaymentSubmit(result);
      } else {
        throw new Error(result.error || 'Payment failed');
      }
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'An error occurred';
      
      logError(error instanceof Error ? error : new Error(errorMessage), {
        context: 'payment_processing',
        planName,
        planPrice,
        email: formData.email
      });
      
      trackEvent('payment_failed', { 
        planName, 
        planPrice,
        error: errorMessage 
      });
      
      toast({
        title: "Payment Failed",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCancel = () => {
    trackEvent('payment_cancelled', { planName, planPrice });
    onCancel();
  };

  return (
    <Card className="max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="h-5 w-5" />
          Payment Details
        </CardTitle>
        <CardDescription>
          Subscribe to {planName} - {planPrice}/month
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              id="email"
              type="email"
              placeholder="john@example.com"
              value={formData.email}
              onChange={(e) => handleInputChange('email', e.target.value)}
              required
            />
          </div>
          
          <div>
            <Label htmlFor="cardNumber">Card Number</Label>
            <Input
              id="cardNumber"
              placeholder="1234 5678 9012 3456"
              value={formData.cardNumber}
              onChange={(e) => handleInputChange('cardNumber', e.target.value)}
              required
            />
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="expiryDate">Expiry Date</Label>
              <Input
                id="expiryDate"
                placeholder="MM/YY"
                value={formData.expiryDate}
                onChange={(e) => handleInputChange('expiryDate', e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="cvv">CVV</Label>
              <Input
                id="cvv"
                placeholder="123"
                value={formData.cvv}
                onChange={(e) => handleInputChange('cvv', e.target.value)}
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="cardholderName">Cardholder Name</Label>
            <Input
              id="cardholderName"
              placeholder="John Doe"
              value={formData.cardholderName}
              onChange={(e) => handleInputChange('cardholderName', e.target.value)}
              required
            />
          </div>

          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Lock className="h-4 w-4" />
            <span>Your payment information is secure and encrypted</span>
          </div>

          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={handleCancel} className="flex-1" disabled={loading}>
              Cancel
            </Button>
            <Button type="submit" className="flex-1" disabled={loading}>
              {loading ? 'Processing...' : 'Subscribe Now'}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
};