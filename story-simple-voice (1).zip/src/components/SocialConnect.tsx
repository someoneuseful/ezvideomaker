import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Facebook, Twitter, Instagram, Youtube, Linkedin, Hash } from 'lucide-react';

interface SocialNetwork {
  id: string;
  name: string;
  icon: React.ComponentType<any>;
  connected: boolean;
  followers?: number;
}

const SocialConnect: React.FC = () => {
  const { toast } = useToast();
  const [networks, setNetworks] = useState<SocialNetwork[]>([
    { id: 'facebook', name: 'Facebook', icon: Facebook, connected: false, followers: 0 },
    { id: 'twitter', name: 'Twitter', icon: Twitter, connected: false, followers: 0 },
    { id: 'instagram', name: 'Instagram', icon: Instagram, connected: false, followers: 0 },
    { id: 'youtube', name: 'YouTube', icon: Youtube, connected: false, followers: 0 },
    { id: 'linkedin', name: 'LinkedIn', icon: Linkedin, connected: false, followers: 0 },
    { id: 'tiktok', name: 'TikTok', icon: Hash, connected: false, followers: 0 },
  ]);

  const handleConnect = (networkId: string) => {
    setNetworks(prev => prev.map(network => 
      network.id === networkId 
        ? { ...network, connected: !network.connected, followers: network.connected ? 0 : Math.floor(Math.random() * 10000) }
        : network
    ));
    
    const network = networks.find(n => n.id === networkId);
    toast({
      title: network?.connected ? 'Disconnected' : 'Connected',
      description: `${network?.name} ${network?.connected ? 'disconnected' : 'connected'} successfully`,
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Social Media Connections</CardTitle>
        <CardDescription>Connect your social media accounts to share your videos</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {networks.map((network) => {
            const IconComponent = network.icon;
            return (
              <div key={network.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-3">
                  <IconComponent className="h-6 w-6" />
                  <div>
                    <p className="font-medium">{network.name}</p>
                    {network.connected && (
                      <p className="text-sm text-muted-foreground">{network.followers} followers</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {network.connected && <Badge variant="secondary">Connected</Badge>}
                  <Button
                    variant={network.connected ? "outline" : "default"}
                    size="sm"
                    onClick={() => handleConnect(network.id)}
                  >
                    {network.connected ? 'Disconnect' : 'Connect'}
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default SocialConnect;