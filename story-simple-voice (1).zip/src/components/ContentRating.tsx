import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Shield, Users } from "lucide-react";

const ContentRating = () => {
  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="flex justify-center mb-2">
          <Shield className="h-8 w-8 text-green-600" />
        </div>
        <CardTitle className="text-lg">Content Rating</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="text-center">
          <Badge variant="secondary" className="text-lg px-4 py-2">
            Everyone (E)
          </Badge>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-blue-600" />
            <span className="text-sm">Suitable for all ages</span>
          </div>
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 text-yellow-600" />
            <span className="text-sm">User-generated content</span>
          </div>
        </div>
        
        <div className="text-xs text-muted-foreground">
          <p>This app allows users to create videos from images and text. Content is user-generated and may vary.</p>
        </div>
      </CardContent>
    </Card>
  );
};

export default ContentRating;