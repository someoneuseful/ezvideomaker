import React from 'react';
import VideoTypeCard from './VideoTypeCard';
import VideoExamples from './VideoExamples';

const VideoTypesShowcase: React.FC = () => {
  const videoTypes = [
    {
      title: '2D Animation',
      description: 'Create vibrant flat-style animations perfect for explainer videos, educational content, and storytelling.',
      imageUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgdmlld0JveD0iMCAwIDQwMCAzMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJhIiB4MT0iMCIgeTE9IjAiIHgyPSI0MDAiIHkyPSIzMDAiPjxzdG9wIHN0b3AtY29sb3I9IiNmZjZkOTIiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmZjk5NzMiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgZmlsbD0idXJsKCNhKSIvPjxjaXJjbGUgY3g9IjEwMCIgY3k9IjEwMCIgcj0iNDAiIGZpbGw9IiNmZmYiLz48cmVjdCB4PSIyMDAiIHk9IjUwIiB3aWR0aD0iMTUwIiBoZWlnaHQ9IjEwMCIgcng9IjEwIiBmaWxsPSIjZmZmIi8+PHBhdGggZD0iTTUwIDIwMGwxMDAtNTAgMTAwIDUwdjUwSDE1MHYtMjVsLTUwIDI1djI1SDUwdi01MHoiIGZpbGw9IiNmZmYiLz48L3N2Zz4=',
      tags: ['Flat Design', 'Educational', 'Explainer'],
      isPopular: true
    },
    {
      title: '3D Animation',
      description: 'Professional 3D renders and animations with realistic lighting, textures, and dynamic camera movements.',
      imageUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgdmlld0JveD0iMCAwIDQwMCAzMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJiIiB4MT0iMCIgeTE9IjAiIHgyPSI0MDAiIHkyPSIzMDAiPjxzdG9wIHN0b3AtY29sb3I9IiM2MzY2ZjEiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiM4YjVjZjYiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgZmlsbD0idXJsKCNiKSIvPjxwb2x5Z29uIHBvaW50cz0iMjAwLDUwIDI4MCwxMDAgMjgwLDE4MCAyMDAsMjMwIDEyMCwxODAgMTIwLDEwMCIgZmlsbD0iI2ZmZiIgb3BhY2l0eT0iMC45Ii8+PHBvbHlnb24gcG9pbnRzPSIyMDAsNTAgMjgwLDEwMCAyMDAsMTUwIDEyMCwxMDAiIGZpbGw9IiNmZmYiLz48cG9seWdvbiBwb2ludHM9IjIwMCwxNTAgMjgwLDEwMCAyODAsMTgwIDIwMCwyMzAiIGZpbGw9IiNmZmYiIG9wYWNpdHk9IjAuOCIvPjxwb2x5Z29uIHBvaW50cz0iMjAwLDE1MCAxMjAsMTAwIDEyMCwxODAgMjAwLDIzMCIgZmlsbD0iI2ZmZiIgb3BhY2l0eT0iMC42Ii8+PC9zdmc+',
      tags: ['Realistic', 'Professional', 'Cinema'],
      isPopular: true
    },
    {
      title: 'Cartoon Style',
      description: 'Fun and engaging cartoon animations perfect for children\'s content, entertainment, and playful storytelling.',
      imageUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgdmlld0JveD0iMCAwIDQwMCAzMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PGxpbmVhckdyYWRpZW50IGlkPSJjIiB4MT0iMCIgeTE9IjAiIHgyPSI0MDAiIHkyPSIzMDAiPjxzdG9wIHN0b3AtY29sb3I9IiNmZGU2OGEiLz48c3RvcCBvZmZzZXQ9IjEiIHN0b3AtY29sb3I9IiNmYWNjMTUiLz48L2xpbmVhckdyYWRpZW50PjwvZGVmcz48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgZmlsbD0idXJsKCNjKSIvPjxjaXJjbGUgY3g9IjIwMCIgY3k9IjEyMCIgcj0iNjAiIGZpbGw9IiNmZmMxMDciLz48Y2lyY2xlIGN4PSIxODAiIGN5PSIxMDAiIHI9IjgiIGZpbGw9IiMzNzM3MzciLz48Y2lyY2xlIGN4PSIyMjAiIGN5PSIxMDAiIHI9IjgiIGZpbGw9IiMzNzM3MzciLz48ZWxsaXBzZSBjeD0iMjAwIiBjeT0iMTQwIiByeD0iMjAiIHJ5PSIxMCIgZmlsbD0iI2ZmNjU5MyIvPjxyZWN0IHg9IjE0MCIgeT0iMTgwIiB3aWR0aD0iMTIwIiBoZWlnaHQ9IjgwIiByeD0iMTAiIGZpbGw9IiM2MzY2ZjEiLz48L3N2Zz4=',
      tags: ['Kids Friendly', 'Entertainment', 'Colorful']
    },
    {
      title: 'Whiteboard Animation',
      description: 'Hand-drawn style animations that simulate drawing on a whiteboard, perfect for educational and business content.',
      imageUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgdmlld0JveD0iMCAwIDQwMCAzMDAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHJlY3Qgd2lkdGg9IjQwMCIgaGVpZ2h0PSIzMDAiIGZpbGw9IiNmOWZhZmIiLz48cGF0aCBkPSJNNTAgMTAwaDMwMCIgc3Ryb2tlPSIjMzc0MTUxIiBzdHJva2Utd2lkdGg9IjMiIHN0cm9rZS1kYXNoYXJyYXk9IjUgNSIvPjxwYXRoIGQ9Ik01MCAyMDBoMzAwIiBzdHJva2U9IiMzNzQxNTEiIHN0cm9rZS13aWR0aD0iMyIgc3Ryb2tlLWRhc2hhcnJheT0iNSA1Ii8+PGNpcmNsZSBjeD0iMTAwIiBjeT0iMTUwIiByPSIyNSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjMzc0MTUxIiBzdHJva2Utd2lkdGg9IjMiLz48cmVjdCB4PSIyMDAiIHk9IjEyNSIgd2lkdGg9IjUwIiBoZWlnaHQ9IjUwIiBmaWxsPSJub25lIiBzdHJva2U9IiMzNzQxNTEiIHN0cm9rZS13aWR0aD0iMyIvPjxwYXRoIGQ9Im0zMDAgMTI1IDI1IDI1LTI1IDI1IiBmaWxsPSJub25lIiBzdHJva2U9IiMzNzQxNTEiIHN0cm9rZS13aWR0aD0iMyIvPjwvc3ZnPg==',
      tags: ['Educational', 'Business', 'Hand-drawn']
    }
  ];

  return (
    <div className="py-16 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 bg-clip-text text-transparent mb-4">
            Choose Your Video Style
          </h2>
          <p className="text-gray-600 text-lg max-w-3xl mx-auto">
            From 2D animations to 3D renders, create videos in the style that best fits your story and audience.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {videoTypes.map((type, index) => (
            <VideoTypeCard
              key={index}
              title={type.title}
              description={type.description}
              imageUrl={type.imageUrl}
              tags={type.tags}
              isPopular={type.isPopular}
            />
          ))}
        </div>
        
        <VideoExamples />
      </div>
    </div>
  );
};

export default VideoTypesShowcase;