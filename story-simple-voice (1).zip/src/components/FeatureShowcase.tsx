import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Mic, Wand2, Share2, Heart, Users, Zap } from 'lucide-react';

const FeatureShowcase: React.FC = () => {
  const features = [
    {
      icon: <Mic className="h-6 w-6" />,
      title: "AI Voice Generation",
      description: "Choose from hundreds of professional voices in multiple languages",
      color: "bg-blue-500"
    },
    {
      icon: <Wand2 className="h-6 w-6" />,
      title: "Auto Video Creation",
      description: "Automatically creates transitions, captions, and perfect timing",
      color: "bg-purple-500"
    },
    {
      icon: <Share2 className="h-6 w-6" />,
      title: "One-Click Sharing",
      description: "Share directly to TikTok, Instagram, or YouTube Shorts",
      color: "bg-pink-500"
    },
    {
      icon: <Heart className="h-6 w-6" />,
      title: "Made for Everyone",
      description: "Perfect for content creators, marketers, and storytellers",
      color: "bg-red-500"
    },
    {
      icon: <Users className="h-6 w-6" />,
      title: "Professional Quality",
      description: "Create studio-quality videos without expensive equipment",
      color: "bg-green-500"
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "Lightning Fast",
      description: "Create professional videos in minutes, not hours",
      color: "bg-orange-500"
    }
  ];

  return (
    <div className="mt-12">
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-2">Why Choose EzClickVideoMaker?</h3>
        <p className="text-gray-600">Create amazing videos with just a click</p>
      </div>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <Card key={index} className="hover:shadow-lg transition-shadow border-0 bg-white/80 backdrop-blur">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <div className={`${feature.color} text-white p-3 rounded-full flex-shrink-0`}>
                  {feature.icon}
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">{feature.title}</h4>
                  <p className="text-sm text-gray-600">{feature.description}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      <div className="mt-8 text-center">
        <Badge variant="secondary" className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0 px-4 py-2">
          ✨ Powered by Something Useful, Inc. ✨
        </Badge>
      </div>
    </div>
  );
};

export default FeatureShowcase;