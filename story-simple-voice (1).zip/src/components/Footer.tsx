import { Link } from "react-router-dom";
import { Separator } from "@/components/ui/separator";

const Footer = () => {
  return (
    <footer className="bg-white border-t mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <img 
                src="https://d64gsuwffb70l.cloudfront.net/68500b41da0586b2a971dad7_1750089688409_28cc4622.jpg" 
                alt="SUI Logo" 
                className="h-8 w-8 object-contain"
              />
              <h3 className="text-lg font-semibold text-gray-900">
                EzClickVideoMaker
              </h3>
            </div>
            <p className="text-gray-600 mb-4">
              Create amazing videos with just a click. Professional video creation made simple.
            </p>
            <p className="text-sm text-gray-500">
              © 2024 Something Useful, Inc. All rights reserved.
            </p>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-4">Legal</h4>
            <ul className="space-y-2">
              <li>
                <Link to="/privacy" className="text-sm text-gray-600 hover:text-gray-900">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link to="/terms" className="text-sm text-gray-600 hover:text-gray-900">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link to="/refund" className="text-sm text-gray-600 hover:text-gray-900">
                  Refund Policy
                </Link>
              </li>
              <li>
                <Link to="/compliance" className="text-sm text-gray-600 hover:text-gray-900">
                  Google Play Compliance
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-4">Support</h4>
            <ul className="space-y-2">
              <li>
                <a href="mailto:Ezclickvideomaker@gmail.com" className="text-sm text-gray-600 hover:text-gray-900">
                  Contact Support
                </a>
              </li>
              <li>
                <a href="mailto:Ezclickvideomaker@gmail.com" className="text-sm text-gray-600 hover:text-gray-900">
                  Legal Inquiries
                </a>
              </li>
              <li>
                <a href="mailto:Ezclickvideomaker@gmail.com" className="text-sm text-gray-600 hover:text-gray-900">
                  Refund Requests
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <Separator className="my-6" />
        
        <div className="text-center text-sm text-gray-500">
          <p>EzClickVideoMaker is a product of Something Useful, Inc.</p>
          <p className="mt-1">Visit us at ezclickvideomaker.com</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;