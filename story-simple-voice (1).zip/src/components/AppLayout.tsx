import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';
import Header from './Header';
import Sidebar from './Sidebar';
import VideoCreator from './VideoCreator';
import FeatureShowcase from './FeatureShowcase';
import VideoTypesShowcase from './VideoTypesShowcase';
import UserForm from './UserForm';
import SocialConnect from './SocialConnect';
import Footer from './Footer';

const AppLayout: React.FC = () => {
  const { sidebarOpen, isUserRegistered, setUserData } = useAppContext();
  const isMobile = useIsMobile();

  const handleUserSubmit = (userData: { username: string; name: string; email: string }) => {
    setUserData(userData);
  };

  if (!isUserRegistered) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 flex flex-col">
        <div className="flex-1 flex items-center justify-center p-6">
          <UserForm onSubmit={handleUserSubmit} />
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        {(!isMobile || sidebarOpen) && <Sidebar />}
        
        <main className="flex-1">
          <VideoTypesShowcase />
          
          <div className="p-6">
            <div className="max-w-4xl mx-auto">
              <div className="mb-8 text-center">
                <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
                  Create Your Story Video
                </h2>
                <p className="text-gray-600 max-w-2xl mx-auto">
                  Transform your photos and stories into powerful videos that inspire, teach, and heal. 
                  Perfect for parents, teachers, and anyone with a message to share.
                </p>
              </div>
              
              <VideoCreator />
              <div className="mt-8">
                <SocialConnect />
              </div>
              <FeatureShowcase />
            </div>
          </div>
        </main>
      </div>
      
      <Footer />
    </div>
  );
};

export default AppLayout;