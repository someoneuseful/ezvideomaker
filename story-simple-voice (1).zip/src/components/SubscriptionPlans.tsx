import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Check } from 'lucide-react';

interface Plan {
  id: string;
  name: string;
  price: string;
  period: string;
  features: string[];
  popular?: boolean;
}

const plans: Plan[] = [
  {
    id: 'free',
    name: 'Free',
    price: '$0',
    period: 'forever',
    features: ['2 videos per month', 'Basic templates', 'Standard quality']
  },
  {
    id: 'pro',
    name: 'Pro',
    price: '$19',
    period: 'month',
    features: ['Unlimited videos', 'Premium templates', 'HD quality', 'Priority support'],
    popular: true
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    price: '$49',
    period: 'month',
    features: ['Everything in Pro', 'Custom branding', 'API access', 'Dedicated support']
  }
];

interface SubscriptionPlansProps {
  onSelectPlan: (planId: string) => void;
}

export const SubscriptionPlans: React.FC<SubscriptionPlansProps> = ({ onSelectPlan }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
      {plans.map((plan) => (
        <Card key={plan.id} className={`relative ${plan.popular ? 'border-primary' : ''}`}>
          {plan.popular && (
            <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2">
              Most Popular
            </Badge>
          )}
          <CardHeader>
            <CardTitle className="text-xl">{plan.name}</CardTitle>
            <CardDescription>
              <span className="text-3xl font-bold">{plan.price}</span>
              <span className="text-muted-foreground">/{plan.period}</span>
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2 mb-6">
              {plan.features.map((feature, index) => (
                <li key={index} className="flex items-center">
                  <Check className="h-4 w-4 text-green-500 mr-2" />
                  <span className="text-sm">{feature}</span>
                </li>
              ))}
            </ul>
            <Button 
              className="w-full" 
              variant={plan.popular ? 'default' : 'outline'}
              onClick={() => onSelectPlan(plan.id)}
            >
              {plan.id === 'free' ? 'Current Plan' : 'Choose Plan'}
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};