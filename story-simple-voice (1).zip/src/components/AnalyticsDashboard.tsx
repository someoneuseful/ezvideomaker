import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart3, AlertTriangle, Download } from 'lucide-react';
import { analytics, crashLogger } from '@/lib/analytics';

export const AnalyticsDashboard: React.FC = () => {
  const events = analytics.getStoredEvents();
  const crashes = crashLogger.getStoredCrashes();
  
  const exportData = () => {
    const data = { events, crashes, exportedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'analytics-data.json';
    a.click();
    URL.revokeObjectURL(url);
  };
  
  const clearData = () => {
    localStorage.removeItem('analytics_events');
    localStorage.removeItem('crash_reports');
    window.location.reload();
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Analytics Dashboard</h2>
        <div className="space-x-2">
          <Button onClick={exportData} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export Data
          </Button>
          <Button onClick={clearData} variant="destructive" size="sm">
            Clear Data
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              Analytics Events ({events.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {events.slice(-10).map((event: any, index: number) => (
                <div key={index} className="text-sm border-b pb-2">
                  <div className="font-medium">{event.name}</div>
                  <div className="text-gray-500">{new Date(event.timestamp).toLocaleString()}</div>
                </div>
              ))}
              {events.length === 0 && (
                <p className="text-gray-500">No events recorded yet</p>
              )}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5" />
              Crash Reports ({crashes.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {crashes.slice(-10).map((crash: any, index: number) => (
                <div key={index} className="text-sm border-b pb-2">
                  <div className="font-medium text-red-600">{crash.message}</div>
                  <div className="text-gray-500">{new Date(crash.timestamp).toLocaleString()}</div>
                </div>
              ))}
              {crashes.length === 0 && (
                <p className="text-gray-500">No crashes recorded</p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};