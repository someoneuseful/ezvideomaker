import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

interface VideoTypeCardProps {
  title: string;
  description: string;
  imageUrl: string;
  tags: string[];
  isPopular?: boolean;
}

const VideoTypeCard: React.FC<VideoTypeCardProps> = ({
  title,
  description,
  imageUrl,
  tags,
  isPopular = false
}) => {
  return (
    <Card className="group cursor-pointer transition-all duration-300 hover:shadow-xl hover:-translate-y-2 bg-white/80 backdrop-blur-sm border-0 shadow-lg">
      <div className="relative overflow-hidden rounded-t-lg">
        {isPopular && (
          <Badge className="absolute top-3 right-3 z-10 bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
            Popular
          </Badge>
        )}
        <div 
          className="h-48 bg-gradient-to-br transition-transform duration-300 group-hover:scale-105"
          style={{ backgroundImage: `url(${imageUrl})`, backgroundSize: 'cover', backgroundPosition: 'center' }}
        />
        <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors duration-300" />
      </div>
      <CardContent className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-purple-600 transition-colors">
          {title}
        </h3>
        <p className="text-gray-600 text-sm mb-4 line-clamp-2">
          {description}
        </p>
        <div className="flex flex-wrap gap-2">
          {tags.map((tag, index) => (
            <Badge key={index} variant="secondary" className="text-xs bg-purple-100 text-purple-700 hover:bg-purple-200">
              {tag}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default VideoTypeCard;