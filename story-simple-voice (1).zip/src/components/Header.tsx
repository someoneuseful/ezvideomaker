import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, Heart, User } from 'lucide-react';
import { useAppContext } from '@/contexts/AppContext';
import { SubscriptionModal } from './SubscriptionModal';

const Header: React.FC = () => {
  const { toggleSidebar, userData, videosRemaining, isPro, currentPlan, upgradeSubscription } = useAppContext();
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);

  const handleUpgradeClick = () => {
    setShowSubscriptionModal(true);
  };

  const handleSubscriptionSuccess = (planId: string) => {
    upgradeSubscription(planId);
    setShowSubscriptionModal(false);
  };

  const getPlanDisplayName = () => {
    switch (currentPlan) {
      case 'pro': return 'Pro Plan';
      case 'enterprise': return 'Enterprise Plan';
      default: return 'Free Plan';
    }
  };

  return (
    <>
      <header className="bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 text-white shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                size="sm"
                onClick={toggleSidebar}
                className="text-white hover:bg-white/20 md:hidden"
              >
                <Menu className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <div className="bg-white/20 p-2 rounded-full">
                  <img 
                    src="https://d64gsuwffb70l.cloudfront.net/68500b41da0586b2a971dad7_1750089688409_28cc4622.jpg" 
                    alt="SUI Logo" 
                    className="h-6 w-6 object-contain"
                  />
                </div>
                <div>
                  <h1 className="text-xl font-bold">EzClickVideoMaker</h1>
                  <p className="text-sm text-white/80">Create amazing videos with just a click</p>
                </div>
              </div>
            </div>
            
            <div className="hidden md:flex items-center gap-4">
              {userData && (
                <div className="flex items-center gap-2 bg-white/10 px-3 py-1 rounded-full">
                  <User className="h-4 w-4" />
                  <span className="text-sm font-medium">{userData.name}</span>
                </div>
              )}
              <div className="text-right">
                <p className="text-sm font-medium">{getPlanDisplayName()}</p>
                <p className="text-xs text-white/80">
                  {videosRemaining === 999 ? 'Unlimited videos' : `${videosRemaining} videos remaining`}
                </p>
              </div>
              {!isPro && (
                <Button 
                  variant="secondary" 
                  size="sm"
                  className="bg-white text-purple-600 hover:bg-white/90"
                  onClick={handleUpgradeClick}
                >
                  <Heart className="h-4 w-4 mr-2" />
                  Upgrade
                </Button>
              )}
            </div>
          </div>
        </div>
      </header>

      <SubscriptionModal
        isOpen={showSubscriptionModal}
        onClose={() => setShowSubscriptionModal(false)}
        onSubscriptionSuccess={handleSubscriptionSuccess}
      />
    </>
  );
};

export default Header;