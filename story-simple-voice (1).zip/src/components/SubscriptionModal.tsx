import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { SubscriptionPlans } from './SubscriptionPlans';
import { PaymentForm } from './PaymentForm';
import { useToast } from '@/hooks/use-toast';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubscriptionSuccess: (planId: string) => void;
}

const planDetails = {
  pro: { name: 'Pro', price: '$19' },
  enterprise: { name: 'Enterprise', price: '$49' }
};

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  isOpen,
  onClose,
  onSubscriptionSuccess
}) => {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [showPayment, setShowPayment] = useState(false);
  const { toast } = useToast();

  const handlePlanSelect = (planId: string) => {
    if (planId === 'free') {
      toast({
        title: 'Already on Free Plan',
        description: 'You are currently on the free plan.'
      });
      return;
    }
    setSelectedPlan(planId);
    setShowPayment(true);
  };

  const handlePaymentSubmit = async (paymentData: any) => {
    try {
      // Simulate payment processing
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      toast({
        title: 'Subscription Successful!',
        description: `Welcome to ${paymentData.planName}! Your subscription is now active.`
      });
      
      onSubscriptionSuccess(selectedPlan!);
      handleClose();
    } catch (error) {
      toast({
        title: 'Payment Failed',
        description: 'There was an error processing your payment. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleClose = () => {
    setSelectedPlan(null);
    setShowPayment(false);
    onClose();
  };

  const handlePaymentCancel = () => {
    setShowPayment(false);
    setSelectedPlan(null);
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {showPayment ? 'Complete Your Subscription' : 'Choose Your Plan'}
          </DialogTitle>
        </DialogHeader>
        
        {showPayment && selectedPlan ? (
          <PaymentForm
            planName={planDetails[selectedPlan as keyof typeof planDetails].name}
            planPrice={planDetails[selectedPlan as keyof typeof planDetails].price}
            onPaymentSubmit={handlePaymentSubmit}
            onCancel={handlePaymentCancel}
          />
        ) : (
          <SubscriptionPlans onSelectPlan={handlePlanSelect} />
        )}
      </DialogContent>
    </Dialog>
  );
};