import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Camera, Mic, FileImage, Wifi } from "lucide-react";

const AppPermissions = () => {
  const permissions = [
    {
      icon: FileImage,
      name: "Storage Access",
      reason: "To save and access your created videos",
      required: true
    },
    {
      icon: Camera,
      name: "Camera Access",
      reason: "To capture photos for video creation",
      required: false
    },
    {
      icon: Mic,
      name: "Microphone Access",
      reason: "For voice narration features",
      required: false
    },
    {
      icon: Wifi,
      name: "Internet Access",
      reason: "To process videos and sync with cloud storage",
      required: true
    }
  ];

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-xl">App Permissions</CardTitle>
        <p className="text-sm text-muted-foreground">
          Permissions requested by EzClickVideoMaker
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {permissions.map((permission, index) => {
          const IconComponent = permission.icon;
          return (
            <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
              <IconComponent className="h-5 w-5 text-blue-600 mt-1" />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold">{permission.name}</h3>
                  <Badge variant={permission.required ? "default" : "secondary"}>
                    {permission.required ? "Required" : "Optional"}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">
                  {permission.reason}
                </p>
              </div>
            </div>
          );
        })}
        
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Note:</strong> Optional permissions can be granted later through app settings. 
            The app will function with limited features if optional permissions are denied.
          </p>
        </div>
      </CardContent>
    </Card>
  );
};

export default AppPermissions;