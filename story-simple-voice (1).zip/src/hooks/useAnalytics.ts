import { useEffect } from 'react';
import { analytics, crashLogger, trackEvent } from '@/lib/analytics';

export const useAnalytics = () => {
  useEffect(() => {
    // Initialize analytics on mount
    trackEvent('app_started');
    
    // Set up global error handler
    const handleError = (event: ErrorEvent) => {
      crashLogger.logCrash({
        error: new Error(event.message),
        context: {
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        }
      });
    };
    
    // Set up unhandled promise rejection handler
    const handleUnhandledRejection = (event: PromiseRejectionEvent) => {
      crashLogger.logCrash({
        error: new Error(`Unhandled Promise Rejection: ${event.reason}`),
        context: {
          type: 'unhandled_promise_rejection',
          reason: event.reason
        }
      });
    };
    
    window.addEventListener('error', handleError);
    window.addEventListener('unhandledrejection', handleUnhandledRejection);
    
    return () => {
      window.removeEventListener('error', handleError);
      window.removeEventListener('unhandledrejection', handleUnhandledRejection);
    };
  }, []);
  
  return {
    trackEvent,
    setUserId: (userId: string) => analytics.setUserId(userId),
    setAnalyticsEnabled: (enabled: boolean) => analytics.setEnabled(enabled),
    setCrashLoggingEnabled: (enabled: boolean) => crashLogger.setEnabled(enabled)
  };
};